
echo "====================WEBSITE OVERFLOW======================";
$x = read-host "Number of websites (max none)";
    $y = 0;
    for ($y = 0; $y -lt $x; $y++) {
    cmd /c "start chrome.exe yt.be";
    
    
    }
    
    $y = 0;